import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:my_baust/core/services/academic_service.dart';
import 'package:my_baust/models/attendance_model.dart';
import 'package:my_baust/models/result_model.dart';

/// Lightweight analytics built on top of AcademicService and Firestore.
/// All metrics are computed from real authorized data — nothing is hardcoded.
class AnalyticsService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final AcademicService _academic = AcademicService();

  // ───────────────────── Student-level analytics ─────────────────────

  Future<StudentAnalytics> getStudentAnalytics(String studentId) async {
    final results = await _academic.getStudentResults(studentId);
    final attendance = await _academic.getStudentAttendance(studentId);

    final overallCgpa = _academic.calculateCgpa(results);
    final overallAttendance =
        _academic.calculateOverallAttendance(attendance);

    // Semester GPA trend
    final bySemester = _academic.groupBySemester(results);
    final semesterGpas = <String, double>{};
    for (final entry in bySemester.entries) {
      semesterGpas[entry.key] = _academic.calculateCgpa(entry.value);
    }

    // Subject performance (course → GPA)
    final subjectGpas = <String, double>{};
    for (final r in results) {
      subjectGpas[r.courseCode] = r.gpa;
    }

    // Grade distribution (simple buckets)
    final gradeBuckets = <String, int>{
      'A (3.5–4.0)': 0,
      'B (3.0–3.49)': 0,
      'C (2.0–2.99)': 0,
      'D/F (<2.0)': 0,
    };
    for (final r in results) {
      if (r.gpa >= 3.5) {
        gradeBuckets['A (3.5–4.0)'] = gradeBuckets['A (3.5–4.0)']! + 1;
      } else if (r.gpa >= 3.0) {
        gradeBuckets['B (3.0–3.49)'] = gradeBuckets['B (3.0–3.49)']! + 1;
      } else if (r.gpa >= 2.0) {
        gradeBuckets['C (2.0–2.99)'] = gradeBuckets['C (2.0–2.99)']! + 1;
      } else {
        gradeBuckets['D/F (<2.0)'] = gradeBuckets['D/F (<2.0)']! + 1;
      }
    }

    return StudentAnalytics(
      overallCgpa: overallCgpa,
      overallAttendance: overallAttendance,
      totalCourses: results.length,
      semesterGpas: semesterGpas,
      subjectGpas: subjectGpas,
      gradeDistribution: gradeBuckets,
      results: results,
      attendanceRecords: attendance,
    );
  }

  // ───────────────────── Teacher / class analytics ───────────────────

  /// Aggregate analytics for students in a department (optionally filtered).
  Future<ClassAnalytics> getDepartmentAnalytics({
    required String department,
    String? batch,
    String? section,
    String? level,
  }) async {
    final dept = department.trim().toUpperCase();

    // Note: Firestore equality is case-sensitive. We query uppercase first,
    // then fall back to case-insensitive client filter for older records.
    var snapshot = await _firestore
        .collection('students')
        .where('department', isEqualTo: dept)
        .get();

    if (snapshot.docs.isEmpty) {
      snapshot = await _firestore.collection('students').get();
    }

    var students = snapshot.docs.map((d) {
      final data = d.data() as Map<String, dynamic>;
      return {
        'studentId': data['studentId']?.toString() ?? d.id,
        'name': data['name']?.toString() ?? '',
        'batch': data['batch']?.toString() ?? '',
        'section': data['section']?.toString() ?? '',
        'level': data['level']?.toString() ?? '',
        'department': data['department']?.toString() ?? '',
        'cgpa': (data['cgpa'] is num) ? (data['cgpa'] as num).toDouble() : 0.0,
      };
    }).where((s) {
      final d = (s['department'] as String).trim().toUpperCase();
      return d == dept;
    }).toList();

    if (batch != null && batch.isNotEmpty) {
      students = students.where((s) => s['batch'] == batch).toList();
    }
    if (section != null && section.isNotEmpty) {
      students = students.where((s) => s['section'] == section).toList();
    }
    if (level != null && level.isNotEmpty) {
      students = students.where((s) => s['level'] == level).toList();
    }

    final cgpas = students
        .map((s) => s['cgpa'] as double)
        .where((c) => c > 0)
        .toList();

    double avgCgpa = 0;
    if (cgpas.isNotEmpty) {
      avgCgpa = cgpas.reduce((a, b) => a + b) / cgpas.length;
      avgCgpa = double.parse(avgCgpa.toStringAsFixed(2));
    }

    // CGPA distribution buckets
    final dist = <String, int>{
      '3.5–4.0': 0,
      '3.0–3.49': 0,
      '2.5–2.99': 0,
      '2.0–2.49': 0,
      '<2.0': 0,
    };
    for (final c in cgpas) {
      if (c >= 3.5) {
        dist['3.5–4.0'] = dist['3.5–4.0']! + 1;
      } else if (c >= 3.0) {
        dist['3.0–3.49'] = dist['3.0–3.49']! + 1;
      } else if (c >= 2.5) {
        dist['2.5–2.99'] = dist['2.5–2.99']! + 1;
      } else if (c >= 2.0) {
        dist['2.0–2.49'] = dist['2.0–2.49']! + 1;
      } else {
        dist['<2.0'] = dist['<2.0']! + 1;
      }
    }

    return ClassAnalytics(
      studentCount: students.length,
      averageCgpa: avgCgpa,
      cgpaDistribution: dist,
      students: students,
    );
  }
}

class StudentAnalytics {
  final double overallCgpa;
  final double overallAttendance;
  final int totalCourses;
  final Map<String, double> semesterGpas;
  final Map<String, double> subjectGpas;
  final Map<String, int> gradeDistribution;
  final List<ResultModel> results;
  final List<AttendanceModel> attendanceRecords;

  StudentAnalytics({
    required this.overallCgpa,
    required this.overallAttendance,
    required this.totalCourses,
    required this.semesterGpas,
    required this.subjectGpas,
    required this.gradeDistribution,
    required this.results,
    required this.attendanceRecords,
  });
}

class ClassAnalytics {
  final int studentCount;
  final double averageCgpa;
  final Map<String, int> cgpaDistribution;
  final List<Map<String, dynamic>> students;

  ClassAnalytics({
    required this.studentCount,
    required this.averageCgpa,
    required this.cgpaDistribution,
    required this.students,
  });
}
