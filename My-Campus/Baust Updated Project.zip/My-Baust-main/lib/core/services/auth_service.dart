import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  User? get currentUser => _auth.currentUser;

  Stream<User?> get authStateChanges => _auth.authStateChanges();

  /// Sign up a new student.
  /// Creates Firebase Auth user + students document + users role document.
  Future<User?> signUpStudent({
    required String email,
    required String password,
    required String name,
    required String studentId,
    required String department,
    required String level,
    required String term,
    required String section,
    required String batch,
  }) async {
    try {
      final credential = await _auth.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );

      final user = credential.user;
      if (user == null) return null;

      await user.updateDisplayName(name);

      // Student academic profile
      await _firestore.collection('students').doc(studentId).set({
        'uid': user.uid,
        'name': name.trim(),
        'email': email.trim(),
        'studentId': studentId.trim(),
        'department': department.trim().toUpperCase(),
        'level': level.trim(),
        'term': term.trim(),
        'section': section.trim(),
        'batch': batch.trim(),
        'cgpa': 0.0,
        'createdAt': FieldValue.serverTimestamp(),
      });

      // Role mapping (used for routing & future security rules)
      await _firestore.collection('users').doc(user.uid).set({
        'uid': user.uid,
        'email': email.trim(),
        'role': 'student',
        'studentId': studentId.trim(),
        'name': name.trim(),
        'department': department.trim().toUpperCase(),
        'createdAt': FieldValue.serverTimestamp(),
      });

      return user;
    } on FirebaseAuthException catch (e) {
      throw Exception(_mapAuthException(e));
    } catch (e) {
      throw Exception('Student signup failed: $e');
    }
  }

  /// Sign up a new teacher.
  Future<User?> signUpTeacher({
    required String email,
    required String password,
    required String name,
    required String department,
  }) async {
    try {
      final credential = await _auth.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );

      final user = credential.user;
      if (user == null) return null;

      await user.updateDisplayName(name);

      await _firestore.collection('teachers').doc(user.uid).set({
        'uid': user.uid,
        'name': name.trim(),
        'email': email.trim(),
        'department': department.trim().toUpperCase(),
        'createdAt': FieldValue.serverTimestamp(),
      });

      await _firestore.collection('users').doc(user.uid).set({
        'uid': user.uid,
        'email': email.trim(),
        'role': 'teacher',
        'name': name.trim(),
        'department': department.trim().toUpperCase(),
        'createdAt': FieldValue.serverTimestamp(),
      });

      return user;
    } on FirebaseAuthException catch (e) {
      throw Exception(_mapAuthException(e));
    } catch (e) {
      throw Exception('Teacher signup failed: $e');
    }
  }

  /// Email + password login. Returns the user and their role.
  Future<Map<String, dynamic>> login({
    required String email,
    required String password,
  }) async {
    try {
      final credential = await _auth.signInWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );

      final user = credential.user;
      if (user == null) {
        throw Exception('Login failed: no user returned');
      }

      final userDoc =
          await _firestore.collection('users').doc(user.uid).get();

      if (!userDoc.exists) {
        throw Exception(
            'User profile not found. Please contact administrator or re-register.');
      }

      final data = userDoc.data()!;
      final role = data['role'] as String? ?? 'student';

      return {
        'user': user,
        'role': role,
        'profile': data,
      };
    } on FirebaseAuthException catch (e) {
      throw Exception(_mapAuthException(e));
    } catch (e) {
      rethrow;
    }
  }

  Future<void> logout() async {
    await _auth.signOut();
  }

  /// Helper to get current user role from Firestore.
  Future<String?> getCurrentUserRole() async {
    final user = _auth.currentUser;
    if (user == null) return null;

    final doc = await _firestore.collection('users').doc(user.uid).get();
    if (!doc.exists) return null;
    return doc.data()?['role'] as String?;
  }

  String _mapAuthException(FirebaseAuthException e) {
    switch (e.code) {
      case 'email-already-in-use':
        return 'This email is already registered.';
      case 'invalid-email':
        return 'Please enter a valid email address.';
      case 'weak-password':
        return 'Password should be at least 6 characters.';
      case 'user-not-found':
        return 'No account found with this email.';
      case 'wrong-password':
        return 'Incorrect password.';
      case 'invalid-credential':
        return 'Invalid email or password.';
      case 'too-many-requests':
        return 'Too many attempts. Please try again later.';
      case 'network-request-failed':
        return 'Network error. Check your connection.';
      default:
        return e.message ?? 'Authentication failed.';
    }
  }
}
