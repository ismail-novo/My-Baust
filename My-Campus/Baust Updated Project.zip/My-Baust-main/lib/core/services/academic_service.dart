import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:my_baust/models/attendance_model.dart';
import 'package:my_baust/models/result_model.dart';
import 'package:my_baust/core/constants/baust_grade_scale.dart';
import 'package:my_baust/models/student_model.dart';

/// Central service for academic records, results, attendance, and CGPA.
class AcademicService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // ───────────────────────────── Results ─────────────────────────────

  Future<List<ResultModel>> getStudentResults(String studentId) async {
    final snapshot = await _firestore
        .collection('results')
        .where('studentId', isEqualTo: studentId)
        .get();

    final results = snapshot.docs
        .map((doc) => ResultModel.fromMap(doc.data(), id: doc.id))
        .toList();

    results.sort((a, b) {
      final sem = a.semester.compareTo(b.semester);
      if (sem != 0) return sem;
      return a.courseCode.compareTo(b.courseCode);
    });

    return results;
  }

  Stream<List<ResultModel>> watchStudentResults(String studentId) {
    return _firestore
        .collection('results')
        .where('studentId', isEqualTo: studentId)
        .snapshots()
        .map((snapshot) {
      final list = snapshot.docs
          .map((doc) => ResultModel.fromMap(doc.data(), id: doc.id))
          .toList();
      list.sort((a, b) => a.semester.compareTo(b.semester));
      return list;
    });
  }

  Future<void> addResult({
    required String studentId,
    required String courseCode,
    required double marks,
    required double gpa,
    required int attendance,
    required String semester,
    double credits = 3.0,
    double ct = 0,
    double mid = 0,
    double lab = 0,
    double finalExam = 0,
  }) async {
    if (studentId.trim().isEmpty) throw Exception('Student ID is required');
    if (courseCode.trim().isEmpty) throw Exception('Course code is required');
    if (gpa < 0 || gpa > 4.0) throw Exception('GPA must be between 0.0 and 4.0');
    if (marks < 0 || marks > 100) throw Exception('Total marks must be between 0 and 100');
    if (credits <= 0) throw Exception('Credits must be positive');

    await _firestore.collection('results').add({
      'studentId': studentId.trim(),
      'courseCode': courseCode.trim().toUpperCase(),
      'marks': marks,
      'gpa': gpa,
      'attendance': attendance,
      'semester': semester.trim(),
      'credits': credits,
      'ct': ct,
      'mid': mid,
      'lab': lab,
      'finalExam': finalExam,
      'createdAt': FieldValue.serverTimestamp(),
    });

    await recalculateAndUpdateCgpa(studentId);
  }

  // ───────────────────────────── Attendance ──────────────────────────

  Future<List<AttendanceModel>> getStudentAttendance(String studentId) async {
    final snapshot = await _firestore
        .collection('attendance')
        .where('studentId', isEqualTo: studentId)
        .get();

    final list = snapshot.docs
        .map((doc) => AttendanceModel.fromMap(doc.data(), id: doc.id))
        .toList();

    list.sort((a, b) {
      final sem = a.semester.compareTo(b.semester);
      if (sem != 0) return sem;
      return a.courseCode.compareTo(b.courseCode);
    });

    return list;
  }

  /// Save or update attendance for a student + course + semester.
  /// Uses a composite-friendly approach: query existing then set/update.
  Future<void> saveAttendance({
    required String studentId,
    required String courseCode,
    required String semester,
    required int totalClasses,
    required int attendedClasses,
  }) async {
    if (studentId.trim().isEmpty) throw Exception('Student ID is required');
    if (courseCode.trim().isEmpty) throw Exception('Course code is required');
    if (totalClasses < 0) throw Exception('Total classes cannot be negative');
    if (attendedClasses < 0) throw Exception('Attended classes cannot be negative');
    if (attendedClasses > totalClasses) {
      throw Exception('Attended cannot exceed total classes');
    }

    final existing = await _firestore
        .collection('attendance')
        .where('studentId', isEqualTo: studentId.trim())
        .where('courseCode', isEqualTo: courseCode.trim().toUpperCase())
        .where('semester', isEqualTo: semester.trim())
        .limit(1)
        .get();

    final data = {
      'studentId': studentId.trim(),
      'courseCode': courseCode.trim().toUpperCase(),
      'semester': semester.trim(),
      'totalClasses': totalClasses,
      'attendedClasses': attendedClasses,
      'updatedAt': FieldValue.serverTimestamp(),
    };

    if (existing.docs.isNotEmpty) {
      await existing.docs.first.reference.update(data);
    } else {
      await _firestore.collection('attendance').add(data);
    }
  }

  /// Overall attendance percentage across all recorded courses.
  double calculateOverallAttendance(List<AttendanceModel> records) {
    if (records.isEmpty) return 0.0;
    int total = 0;
    int attended = 0;
    for (final r in records) {
      total += r.totalClasses;
      attended += r.attendedClasses;
    }
    if (total <= 0) return 0.0;
    return double.parse(((attended / total) * 100).toStringAsFixed(1));
  }

  // ───────────────────────────── CGPA ────────────────────────────────

  /// Credit-weighted GPA/CGPA (BAUST formula).
  /// GPA = Σ(Ci × Gi) / Σ(Ci)
  /// F grades (0.0) are included in the divisor when credits > 0.
  /// Rounded to 2 decimal places per BAUST policy.
  double calculateCgpa(List<ResultModel> results) {
    if (results.isEmpty) return 0.0;
    double weighted = 0.0;
    double totalCredits = 0.0;
    for (final r in results) {
      final c = r.credits > 0 ? r.credits : 3.0;
      weighted += c * r.gpa;
      totalCredits += c;
    }
    if (totalCredits <= 0) return 0.0;
    return double.parse((weighted / totalCredits).toStringAsFixed(2));
  }

  Future<double> recalculateAndUpdateCgpa(String studentId) async {
    final results = await getStudentResults(studentId);
    final cgpa = calculateCgpa(results);

    await _firestore.collection('students').doc(studentId).update({
      'cgpa': cgpa,
      'cgpaUpdatedAt': FieldValue.serverTimestamp(),
    });

    return cgpa;
  }

  Future<StudentModel?> getStudent(String studentId) async {
    final doc = await _firestore.collection('students').doc(studentId).get();
    if (!doc.exists) return null;
    return StudentModel.fromMap(doc.data()!);
  }

  Map<String, List<ResultModel>> groupBySemester(List<ResultModel> results) {
    final map = <String, List<ResultModel>>{};
    for (final r in results) {
      map.putIfAbsent(r.semester, () => []).add(r);
    }
    final sortedKeys = map.keys.toList()..sort();
    return {for (final k in sortedKeys) k: map[k]!};
  }

  Map<String, List<AttendanceModel>> groupAttendanceBySemester(
      List<AttendanceModel> records) {
    final map = <String, List<AttendanceModel>>{};
    for (final r in records) {
      map.putIfAbsent(r.semester, () => []).add(r);
    }
    final sortedKeys = map.keys.toList()..sort();
    return {for (final k in sortedKeys) k: map[k]!};
  }
}
