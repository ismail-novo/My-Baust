class AppSizes {
  // Spacing
  static const double xs = 4;
  static const double sm = 8;
  static const double md = 16;
  static const double lg = 24;
  static const double xl = 32;
  static const double xxl = 48;

  // Common
  static const double padding = 20;
  static const double radius = 12;
  static const double radiusSm = 8;
  static const double radiusLg = 16;
  static const double buttonHeight = 50;
  static const double iconSm = 20;
  static const double iconMd = 24;
  static const double iconLg = 32;
}
