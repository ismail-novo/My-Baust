/// Configurable BAUST faculties and departments.
/// Source: https://www.baust.edu.bd/ (public academic structure)
/// Do not hardcode into business logic — use this list for UI/selection.
class BaustDepartments {
  BaustDepartments._();

  static const List<Map<String, String>> faculties = [
    {
      'code': 'FECE',
      'name': 'Faculty of Electrical and Computer Engineering',
    },
    {
      'code': 'FME',
      'name': 'Faculty of Mechanical Engineering',
    },
    {
      'code': 'FCE',
      'name': 'Faculty of Civil Engineering',
    },
    {
      'code': 'FBS',
      'name': 'Faculty of Business Studies',
    },
    {
      'code': 'FSH',
      'name': 'Faculty of Science and Humanities',
    },
  ];

  /// Department code → display name + faculty code
  static const List<Map<String, String>> departments = [
    {'code': 'CSE', 'name': 'Computer Science and Engineering', 'faculty': 'FECE'},
    {'code': 'EEE', 'name': 'Electrical and Electronic Engineering', 'faculty': 'FECE'},
    {'code': 'ICT', 'name': 'Information and Communication Technology', 'faculty': 'FECE'},
    {'code': 'ME', 'name': 'Mechanical Engineering', 'faculty': 'FME'},
    {'code': 'IPE', 'name': 'Industrial and Production Engineering', 'faculty': 'FME'},
    {'code': 'CE', 'name': 'Civil Engineering', 'faculty': 'FCE'},
    {'code': 'DBA', 'name': 'Business Administration', 'faculty': 'FBS'},
    {'code': 'AIS', 'name': 'Accounting and Information Systems', 'faculty': 'FBS'},
    {'code': 'ENG', 'name': 'English', 'faculty': 'FSH'},
    {'code': 'AS', 'name': 'Arts and Sciences', 'faculty': 'FSH'},
  ];

  static List<String> get departmentCodes =>
      departments.map((d) => d['code']!).toList();

  static List<String> get departmentNames =>
      departments.map((d) => d['name']!).toList();

  static String? nameOf(String code) {
    try {
      return departments.firstWhere((d) => d['code'] == code)['name'];
    } catch (_) {
      return null;
    }
  }
}
