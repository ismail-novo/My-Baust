/// Official BAUST undergraduate grading scale
/// Source: BAUST Examination Policy for Undergraduate Programs
/// (Verified from official BAUST Exam Policy PDF)
///
/// GPA / CGPA are credit-weighted:
///   GPA  = Σ(Ci × Gi) / Σ(Ci)
///   CGPA = Σ(TCi × GPAi) / Σ(TCi)
/// Rounded to two decimal places.
class BaustGradeScale {
  BaustGradeScale._();

  /// Returns grade letter for a percentage mark (0–100).
  static String letterFromMarks(double marks) {
    if (marks >= 80) return 'A+';
    if (marks >= 75) return 'A';
    if (marks >= 70) return 'A-';
    if (marks >= 65) return 'B+';
    if (marks >= 60) return 'B';
    if (marks >= 55) return 'B-';
    if (marks >= 50) return 'C+';
    if (marks >= 45) return 'C';
    if (marks >= 40) return 'D';
    return 'F';
  }

  /// Returns grade point for a percentage mark.
  static double pointFromMarks(double marks) {
    if (marks >= 80) return 4.00;
    if (marks >= 75) return 3.75;
    if (marks >= 70) return 3.50;
    if (marks >= 65) return 3.25;
    if (marks >= 60) return 3.00;
    if (marks >= 55) return 2.75;
    if (marks >= 50) return 2.50;
    if (marks >= 45) return 2.25;
    if (marks >= 40) return 2.00;
    return 0.00;
  }

  /// Returns grade point for a letter grade.
  static double pointFromLetter(String letter) {
    switch (letter.trim().toUpperCase()) {
      case 'A+':
        return 4.00;
      case 'A':
        return 3.75;
      case 'A-':
        return 3.50;
      case 'B+':
        return 3.25;
      case 'B':
        return 3.00;
      case 'B-':
        return 2.75;
      case 'C+':
        return 2.50;
      case 'C':
        return 2.25;
      case 'D':
        return 2.00;
      case 'F':
        return 0.00;
      default:
        return 0.00;
    }
  }

  /// Minimum CGPA required for Bachelor's degree (BAUST policy).
  static const double minimumCgpaForDegree = 2.20;

  /// CGPA threshold for Honors / Distinction (BAUST policy).
  static const double honorsCgpaThreshold = 3.75;

  static const List<Map<String, dynamic>> scaleTable = [
    {'marks': '80% and above', 'grade': 'A+', 'point': 4.00},
    {'marks': '75% – <80%', 'grade': 'A', 'point': 3.75},
    {'marks': '70% – <75%', 'grade': 'A-', 'point': 3.50},
    {'marks': '65% – <70%', 'grade': 'B+', 'point': 3.25},
    {'marks': '60% – <65%', 'grade': 'B', 'point': 3.00},
    {'marks': '55% – <60%', 'grade': 'B-', 'point': 2.75},
    {'marks': '50% – <55%', 'grade': 'C+', 'point': 2.50},
    {'marks': '45% – <50%', 'grade': 'C', 'point': 2.25},
    {'marks': '40% – <45%', 'grade': 'D', 'point': 2.00},
    {'marks': 'Below 40%', 'grade': 'F', 'point': 0.00},
  ];
}
