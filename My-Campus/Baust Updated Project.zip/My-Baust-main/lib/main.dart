import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:my_baust/core/theme/app_theme.dart';
import 'package:my_baust/firebase_options.dart';
import 'package:my_baust/features/auth/screens/role_selection_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(const MyCampusApp());
}

class MyCampusApp extends StatelessWidget {
  const MyCampusApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'BAUST-UIMS',
      theme: AppTheme.light,
      home: const RoleSelectionScreen(),
    );
  }
}
