class StudentModel {
  final String? uid;
  final String name;
  final String email;
  final String studentId;
  final String department;
  final String level;
  final String term;
  final String section;
  final String batch;
  final double cgpa;

  StudentModel({
    this.uid,
    required this.name,
    this.email = '',
    required this.studentId,
    required this.department,
    required this.level,
    required this.term,
    required this.section,
    required this.batch,
    required this.cgpa,
  });

  Map<String, dynamic> toMap() {
    return {
      if (uid != null) 'uid': uid,
      'name': name,
      'email': email,
      'studentId': studentId,
      'department': department,
      'level': level,
      'term': term,
      'section': section,
      'batch': batch,
      'cgpa': cgpa,
    };
  }

  factory StudentModel.fromMap(Map<String, dynamic> map) {
    return StudentModel(
      uid: map['uid']?.toString(),
      name: map['name']?.toString() ?? '',
      email: map['email']?.toString() ?? '',
      studentId: map['studentId']?.toString() ?? '',
      department: map['department']?.toString() ?? '',
      level: map['level']?.toString() ?? '',
      term: map['term']?.toString() ?? '',
      section: map['section']?.toString() ?? '',
      batch: map['batch']?.toString() ?? '',
      cgpa: (map['cgpa'] is num) ? (map['cgpa'] as num).toDouble() : 0.0,
    );
  }
}
