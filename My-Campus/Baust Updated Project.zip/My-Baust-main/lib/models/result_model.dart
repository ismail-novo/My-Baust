class ResultModel {
  final String? id;
  final String studentId;
  final String courseCode;
  final double marks; // total (computed or stored)
  final double gpa;
  final int attendance;
  final String semester;
  final double credits;

  /// Assessment breakdown (optional; older records may be 0)
  final double ct; // Class Test
  final double mid; // Midterm
  final double lab; // Lab / Sessional
  final double finalExam; // Final exam

  final DateTime? createdAt;

  ResultModel({
    this.id,
    required this.studentId,
    required this.courseCode,
    required this.marks,
    required this.gpa,
    required this.attendance,
    required this.semester,
    this.credits = 3.0,
    this.ct = 0,
    this.mid = 0,
    this.lab = 0,
    this.finalExam = 0,
    this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'studentId': studentId,
      'courseCode': courseCode,
      'marks': marks,
      'gpa': gpa,
      'attendance': attendance,
      'semester': semester,
      'credits': credits,
      'ct': ct,
      'mid': mid,
      'lab': lab,
      'finalExam': finalExam,
      'createdAt': createdAt?.toIso8601String(),
    };
  }

  factory ResultModel.fromMap(Map<String, dynamic> map, {String? id}) {
    return ResultModel(
      id: id,
      studentId: map['studentId']?.toString() ?? '',
      courseCode: map['courseCode']?.toString() ?? '',
      marks: (map['marks'] is num) ? (map['marks'] as num).toDouble() : 0.0,
      gpa: (map['gpa'] is num) ? (map['gpa'] as num).toDouble() : 0.0,
      attendance:
          (map['attendance'] is num) ? (map['attendance'] as num).toInt() : 0,
      semester: map['semester']?.toString() ?? '',
      credits: (map['credits'] is num)
          ? (map['credits'] as num).toDouble()
          : 3.0,
      ct: (map['ct'] is num) ? (map['ct'] as num).toDouble() : 0.0,
      mid: (map['mid'] is num) ? (map['mid'] as num).toDouble() : 0.0,
      lab: (map['lab'] is num) ? (map['lab'] as num).toDouble() : 0.0,
      finalExam:
          (map['finalExam'] is num) ? (map['finalExam'] as num).toDouble() : 0.0,
      createdAt: map['createdAt'] != null
          ? DateTime.tryParse(map['createdAt'].toString())
          : null,
    );
  }
}
