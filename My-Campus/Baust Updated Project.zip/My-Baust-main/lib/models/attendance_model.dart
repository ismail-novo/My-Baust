class AttendanceModel {
  final String? id;
  final String studentId;
  final String courseCode;
  final String semester;
  final int totalClasses;
  final int attendedClasses;
  final DateTime? updatedAt;

  AttendanceModel({
    this.id,
    required this.studentId,
    required this.courseCode,
    required this.semester,
    required this.totalClasses,
    required this.attendedClasses,
    this.updatedAt,
  });

  double get percentage {
    if (totalClasses <= 0) return 0.0;
    return (attendedClasses / totalClasses) * 100;
  }

  Map<String, dynamic> toMap() {
    return {
      'studentId': studentId,
      'courseCode': courseCode,
      'semester': semester,
      'totalClasses': totalClasses,
      'attendedClasses': attendedClasses,
      'updatedAt': updatedAt?.toIso8601String(),
    };
  }

  factory AttendanceModel.fromMap(Map<String, dynamic> map, {String? id}) {
    return AttendanceModel(
      id: id,
      studentId: map['studentId']?.toString() ?? '',
      courseCode: map['courseCode']?.toString() ?? '',
      semester: map['semester']?.toString() ?? '',
      totalClasses: (map['totalClasses'] is num)
          ? (map['totalClasses'] as num).toInt()
          : 0,
      attendedClasses: (map['attendedClasses'] is num)
          ? (map['attendedClasses'] as num).toInt()
          : 0,
      updatedAt: map['updatedAt'] != null
          ? DateTime.tryParse(map['updatedAt'].toString())
          : null,
    );
  }
}
