import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:my_baust/core/constants/app_colors.dart';

class CGPAChart extends StatelessWidget {
  final double cgpa;

  const CGPAChart({
    super.key,
    required this.cgpa,
  });

  @override
  Widget build(BuildContext context) {
    final clamped = cgpa.clamp(0.0, 4.0);
    final remaining = 4.0 - clamped;

    return SizedBox(
      height: 180,
      child: PieChart(
        PieChartData(
          sectionsSpace: 2,
          centerSpaceRadius: 40,
          sections: [
            PieChartSectionData(
              value: clamped,
              title: clamped.toStringAsFixed(2),
              radius: 50,
              color: AppColors.primary,
              titleStyle: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            PieChartSectionData(
              value: remaining <= 0 ? 0.01 : remaining,
              title: '',
              radius: 42,
              color: AppColors.border,
            ),
          ],
        ),
      ),
    );
  }
}
