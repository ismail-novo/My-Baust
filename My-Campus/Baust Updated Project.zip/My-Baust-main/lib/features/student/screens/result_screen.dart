import 'package:flutter/material.dart';
import 'package:my_baust/core/constants/app_colors.dart';
import 'package:my_baust/core/constants/app_sizes.dart';
import 'package:my_baust/core/services/academic_service.dart';
import 'package:my_baust/models/result_model.dart';
import 'package:my_baust/widgets/empty_state.dart';
import 'package:my_baust/widgets/error_state.dart';
import 'package:my_baust/widgets/loading_widget.dart';

class ResultScreen extends StatefulWidget {
  final String studentId;

  const ResultScreen({
    super.key,
    required this.studentId,
  });

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  final _academicService = AcademicService();
  late Future<List<ResultModel>> _resultsFuture;

  @override
  void initState() {
    super.initState();
    _resultsFuture = _academicService.getStudentResults(widget.studentId);
  }

  Future<void> _refresh() async {
    setState(() {
      _resultsFuture = _academicService.getStudentResults(widget.studentId);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Results'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _refresh,
            tooltip: 'Refresh',
          ),
        ],
      ),
      body: FutureBuilder<List<ResultModel>>(
        future: _resultsFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const LoadingWidget(message: 'Loading results...');
          }

          if (snapshot.hasError) {
            return ErrorState(
              message: 'Failed to load results:\n${snapshot.error}',
              onRetry: _refresh,
            );
          }

          final results = snapshot.data ?? [];

          if (results.isEmpty) {
            return const EmptyState(
              icon: Icons.assignment_outlined,
              title: 'No results yet',
              subtitle: 'Your teachers will add marks here.',
            );
          }

          final grouped = _academicService.groupBySemester(results);
          final overallCgpa = _academicService.calculateCgpa(results);

          return RefreshIndicator(
            onRefresh: _refresh,
            color: AppColors.primary,
            child: ListView(
              padding: const EdgeInsets.all(AppSizes.md),
              children: [
                // Overall CGPA card
                Card(
                  color: AppColors.primary.withValues(alpha: 0.08),
                  child: Padding(
                    padding: const EdgeInsets.all(AppSizes.lg),
                    child: Column(
                      children: [
                        const Text(
                          'Overall CGPA',
                          style: TextStyle(
                            fontSize: 14,
                            color: AppColors.textSecondary,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          overallCgpa.toStringAsFixed(2),
                          style: const TextStyle(
                            fontSize: 36,
                            fontWeight: FontWeight.bold,
                            color: AppColors.primary,
                          ),
                        ),
                        Text(
                          '${results.length} subject(s)',
                          style: const TextStyle(
                            fontSize: 13,
                            color: AppColors.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: AppSizes.md),

                // Grouped by semester
                ...grouped.entries.map((entry) {
                  final semester = entry.key;
                  final semResults = entry.value;
                  final semGpa = _academicService.calculateCgpa(semResults);

                  return Card(
                    margin: const EdgeInsets.only(bottom: AppSizes.sm),
                    child: ExpansionTile(
                      initiallyExpanded: true,
                      tilePadding: const EdgeInsets.symmetric(
                        horizontal: AppSizes.md,
                        vertical: 4,
                      ),
                      title: Text(
                        semester.isEmpty ? 'Unknown Semester' : semester,
                        style: const TextStyle(
                          fontWeight: FontWeight.w600,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      subtitle: Text(
                        'Semester GPA: ${semGpa.toStringAsFixed(2)}',
                        style: const TextStyle(color: AppColors.textSecondary),
                      ),
                      children: [
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          padding: const EdgeInsets.only(bottom: 8),
                          child: DataTable(
                            headingTextStyle: const TextStyle(
                              fontWeight: FontWeight.w600,
                              color: AppColors.textSecondary,
                              fontSize: 13,
                            ),
                            dataTextStyle: const TextStyle(
                              color: AppColors.textPrimary,
                              fontSize: 14,
                            ),
                            columns: const [
                              DataColumn(label: Text('Course')),
                              DataColumn(label: Text('CT')),
                              DataColumn(label: Text('Mid')),
                              DataColumn(label: Text('Lab')),
                              DataColumn(label: Text('Final')),
                              DataColumn(label: Text('Total')),
                              DataColumn(label: Text('GPA')),
                            ],
                            rows: semResults.map((r) {
                              return DataRow(cells: [
                                DataCell(Text(r.courseCode)),
                                DataCell(Text(r.ct.toStringAsFixed(0))),
                                DataCell(Text(r.mid.toStringAsFixed(0))),
                                DataCell(Text(r.lab.toStringAsFixed(0))),
                                DataCell(Text(r.finalExam.toStringAsFixed(0))),
                                DataCell(Text(r.marks.toStringAsFixed(1))),
                                DataCell(Text(r.gpa.toStringAsFixed(2))),
                              ]);
                            }).toList(),
                          ),
                        ),
                      ],
                    ),
                  );
                }),
              ],
            ),
          );
        },
      ),
    );
  }
}
