import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:my_baust/core/constants/app_colors.dart';
import 'package:my_baust/core/constants/app_sizes.dart';
import 'package:my_baust/core/services/auth_service.dart';
import 'package:my_baust/features/auth/screens/role_selection_screen.dart';
import 'package:my_baust/features/student/screens/attendance_screen.dart';
import 'package:my_baust/features/student/screens/student_analytics_screen.dart';
import 'package:my_baust/features/student/screens/result_screen.dart';
import 'package:my_baust/features/student/widgets/cgpa_chart.dart';
import 'package:my_baust/widgets/error_state.dart';
import 'package:my_baust/widgets/loading_widget.dart';
import 'package:my_baust/widgets/section_header.dart';

class StudentDashboard extends StatelessWidget {
  final String studentId;

  const StudentDashboard({
    super.key,
    required this.studentId,
  });

  @override
  Widget build(BuildContext context) {
    final authService = AuthService();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Student Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Logout',
            onPressed: () async {
              await authService.logout();
              if (context.mounted) {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const RoleSelectionScreen(),
                  ),
                  (route) => false,
                );
              }
            },
          ),
        ],
      ),
      body: FutureBuilder<DocumentSnapshot>(
        future: FirebaseFirestore.instance
            .collection('students')
            .doc(studentId)
            .get(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const LoadingWidget(message: 'Loading profile...');
          }

          if (snapshot.hasError) {
            return ErrorState(
              message: 'Error loading profile: ${snapshot.error}',
            );
          }

          if (!snapshot.hasData || !snapshot.data!.exists) {
            return const ErrorState(
              message: 'Student profile not found.',
            );
          }

          final data = snapshot.data!.data() as Map<String, dynamic>;
          final name = data['name']?.toString() ?? 'Student';
          final department = data['department']?.toString() ?? '-';
          final batch = data['batch']?.toString() ?? '-';
          final level = data['level']?.toString() ?? '-';
          final term = data['term']?.toString() ?? '-';
          final section = data['section']?.toString() ?? '-';
          final cgpa = (data['cgpa'] is num)
              ? (data['cgpa'] as num).toDouble()
              : 0.0;

          return SingleChildScrollView(
            padding: const EdgeInsets.all(AppSizes.md),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Profile card
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(AppSizes.md),
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 28,
                          backgroundColor: AppColors.primary.withValues(alpha: 0.15),
                          child: Text(
                            name.isNotEmpty ? name[0].toUpperCase() : 'S',
                            style: const TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              color: AppColors.primary,
                            ),
                          ),
                        ),
                        const SizedBox(width: AppSizes.md),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                name,
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                studentId,
                                style: const TextStyle(
                                  color: AppColors.textSecondary,
                                ),
                              ),
                              Text(
                                department,
                                style: const TextStyle(
                                  color: AppColors.textSecondary,
                                  fontSize: 13,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: AppSizes.md),

                // Academic info chips
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _InfoChip(label: 'Batch', value: batch),
                    _InfoChip(label: 'Level', value: level),
                    _InfoChip(label: 'Term', value: term),
                    _InfoChip(label: 'Section', value: section),
                  ],
                ),
                const SizedBox(height: AppSizes.lg),

                // CGPA section
                const SectionHeader(title: 'Current CGPA'),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(AppSizes.md),
                    child: Column(
                      children: [
                        CGPAChart(cgpa: cgpa),
                        const SizedBox(height: AppSizes.sm),
                        Text(
                          cgpa.toStringAsFixed(2),
                          style: const TextStyle(
                            fontSize: 28,
                            fontWeight: FontWeight.bold,
                            color: AppColors.primary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: AppSizes.lg),

                // Actions
                const SectionHeader(title: 'Quick Actions'),
                SizedBox(
                  height: AppSizes.buttonHeight,
                  child: ElevatedButton.icon(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ResultScreen(studentId: studentId),
                        ),
                      );
                    },
                    icon: const Icon(Icons.assignment_outlined),
                    label: const Text('View My Results'),
                  ),
                ),
                const SizedBox(height: AppSizes.sm),
                SizedBox(
                  height: AppSizes.buttonHeight,
                  child: OutlinedButton.icon(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => AttendanceScreen(studentId: studentId),
                        ),
                      );
                    },
                    icon: const Icon(Icons.event_available_outlined),
                    label: const Text('View My Attendance'),
                  ),
                ),
                const SizedBox(height: AppSizes.sm),
                SizedBox(
                  height: AppSizes.buttonHeight,
                  child: OutlinedButton.icon(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => StudentAnalyticsScreen(studentId: studentId),
                        ),
                      );
                    },
                    icon: const Icon(Icons.analytics_outlined),
                    label: const Text('My Analytics'),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _InfoChip extends StatelessWidget {
  final String label;
  final String value;

  const _InfoChip({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: AppColors.primary.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.primary.withValues(alpha: 0.2)),
      ),
      child: Text(
        '$label: $value',
        style: const TextStyle(
          fontSize: 13,
          color: AppColors.primary,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }
}
