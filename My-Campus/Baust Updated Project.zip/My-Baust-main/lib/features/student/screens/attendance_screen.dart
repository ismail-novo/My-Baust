import 'package:flutter/material.dart';
import 'package:my_baust/core/constants/app_colors.dart';
import 'package:my_baust/core/constants/app_sizes.dart';
import 'package:my_baust/core/services/academic_service.dart';
import 'package:my_baust/models/attendance_model.dart';
import 'package:my_baust/widgets/empty_state.dart';
import 'package:my_baust/widgets/error_state.dart';
import 'package:my_baust/widgets/loading_widget.dart';

class AttendanceScreen extends StatefulWidget {
  final String studentId;

  const AttendanceScreen({
    super.key,
    required this.studentId,
  });

  @override
  State<AttendanceScreen> createState() => _AttendanceScreenState();
}

class _AttendanceScreenState extends State<AttendanceScreen> {
  final _academicService = AcademicService();
  late Future<List<AttendanceModel>> _future;

  @override
  void initState() {
    super.initState();
    _future = _academicService.getStudentAttendance(widget.studentId);
  }

  Future<void> _refresh() async {
    setState(() {
      _future = _academicService.getStudentAttendance(widget.studentId);
    });
  }

  Color _percentageColor(double pct) {
    if (pct >= 75) return AppColors.success;
    if (pct >= 60) return AppColors.warning;
    return AppColors.error;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Attendance'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _refresh,
          ),
        ],
      ),
      body: FutureBuilder<List<AttendanceModel>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const LoadingWidget(message: 'Loading attendance...');
          }

          if (snapshot.hasError) {
            return ErrorState(
              message: 'Failed to load attendance:\n${snapshot.error}',
              onRetry: _refresh,
            );
          }

          final records = snapshot.data ?? [];

          if (records.isEmpty) {
            return const EmptyState(
              icon: Icons.event_available_outlined,
              title: 'No attendance records',
              subtitle: 'Your teachers will update attendance here.',
            );
          }

          final overall = _academicService.calculateOverallAttendance(records);
          final grouped = _academicService.groupAttendanceBySemester(records);

          return RefreshIndicator(
            onRefresh: _refresh,
            color: AppColors.primary,
            child: ListView(
              padding: const EdgeInsets.all(AppSizes.md),
              children: [
                Card(
                  color: _percentageColor(overall).withValues(alpha: 0.1),
                  child: Padding(
                    padding: const EdgeInsets.all(AppSizes.lg),
                    child: Column(
                      children: [
                        const Text(
                          'Overall Attendance',
                          style: TextStyle(
                            fontSize: 14,
                            color: AppColors.textSecondary,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '${overall.toStringAsFixed(1)}%',
                          style: TextStyle(
                            fontSize: 36,
                            fontWeight: FontWeight.bold,
                            color: _percentageColor(overall),
                          ),
                        ),
                        Text(
                          '${records.length} course(s)',
                          style: const TextStyle(
                            fontSize: 13,
                            color: AppColors.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: AppSizes.md),
                ...grouped.entries.map((entry) {
                  final semester = entry.key;
                  final list = entry.value;

                  return Card(
                    margin: const EdgeInsets.only(bottom: AppSizes.sm),
                    child: ExpansionTile(
                      initiallyExpanded: true,
                      title: Text(
                        semester.isEmpty ? 'Unknown Semester' : semester,
                        style: const TextStyle(fontWeight: FontWeight.w600),
                      ),
                      children: list.map((r) {
                        final pct = r.percentage;
                        return ListTile(
                          title: Text(r.courseCode),
                          subtitle: Text(
                            '${r.attendedClasses} / ${r.totalClasses} classes',
                          ),
                          trailing: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: _percentageColor(pct).withValues(alpha: 0.15),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              '${pct.toStringAsFixed(1)}%',
                              style: TextStyle(
                                fontWeight: FontWeight.w600,
                                color: _percentageColor(pct),
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  );
                }),
              ],
            ),
          );
        },
      ),
    );
  }
}
