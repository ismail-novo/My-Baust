import 'package:flutter/material.dart';
import 'package:my_baust/core/constants/app_colors.dart';
import 'package:my_baust/core/constants/app_sizes.dart';
import 'package:my_baust/core/services/analytics_service.dart';
import 'package:my_baust/features/analytics/widgets/bar_chart_widget.dart';
import 'package:my_baust/widgets/empty_state.dart';
import 'package:my_baust/widgets/error_state.dart';
import 'package:my_baust/widgets/loading_widget.dart';
import 'package:my_baust/widgets/section_header.dart';

class StudentAnalyticsScreen extends StatefulWidget {
  final String studentId;

  const StudentAnalyticsScreen({super.key, required this.studentId});

  @override
  State<StudentAnalyticsScreen> createState() => _StudentAnalyticsScreenState();
}

class _StudentAnalyticsScreenState extends State<StudentAnalyticsScreen> {
  final _service = AnalyticsService();
  late Future<StudentAnalytics> _future;

  @override
  void initState() {
    super.initState();
    _future = _service.getStudentAnalytics(widget.studentId);
  }

  Future<void> _refresh() async {
    setState(() {
      _future = _service.getStudentAnalytics(widget.studentId);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Analytics'),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _refresh),
        ],
      ),
      body: FutureBuilder<StudentAnalytics>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const LoadingWidget(message: 'Computing analytics...');
          }
          if (snapshot.hasError) {
            return ErrorState(
              message: '${snapshot.error}',
              onRetry: _refresh,
            );
          }

          final a = snapshot.data!;
          if (a.totalCourses == 0 && a.attendanceRecords.isEmpty) {
            return const EmptyState(
              icon: Icons.analytics_outlined,
              title: 'Not enough data yet',
              subtitle: 'Results and attendance will appear here once teachers add them.',
            );
          }

          return RefreshIndicator(
            onRefresh: _refresh,
            child: ListView(
              padding: const EdgeInsets.all(AppSizes.md),
              children: [
                // KPI row
                Row(
                  children: [
                    Expanded(
                      child: _KpiCard(
                        label: 'CGPA',
                        value: a.overallCgpa.toStringAsFixed(2),
                        color: AppColors.primary,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _KpiCard(
                        label: 'Attendance',
                        value: '${a.overallAttendance.toStringAsFixed(1)}%',
                        color: a.overallAttendance >= 75
                            ? AppColors.success
                            : a.overallAttendance >= 60
                                ? AppColors.warning
                                : AppColors.error,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _KpiCard(
                        label: 'Courses',
                        value: '${a.totalCourses}',
                        color: AppColors.secondary,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: AppSizes.lg),

                if (a.semesterGpas.isNotEmpty) ...[
                  const SectionHeader(title: 'Semester GPA Trend'),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(AppSizes.md),
                      child: SimpleBarChart(data: a.semesterGpas),
                    ),
                  ),
                  const SizedBox(height: AppSizes.lg),
                ],

                if (a.subjectGpas.isNotEmpty) ...[
                  const SectionHeader(title: 'Subject Performance'),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(AppSizes.md),
                      child: SimpleBarChart(
                        data: a.subjectGpas,
                        maxY: 4.0,
                      ),
                    ),
                  ),
                  const SizedBox(height: AppSizes.lg),
                ],

                if (a.gradeDistribution.values.any((v) => v > 0)) ...[
                  const SectionHeader(title: 'Grade Distribution'),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(AppSizes.md),
                      child: Column(
                        children: a.gradeDistribution.entries.map((e) {
                          final total = a.totalCourses == 0 ? 1 : a.totalCourses;
                          final pct = (e.value / total * 100);
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 6),
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 100,
                                  child: Text(e.key, style: const TextStyle(fontSize: 13)),
                                ),
                                Expanded(
                                  child: LinearProgressIndicator(
                                    value: e.value / total,
                                    backgroundColor: AppColors.border,
                                    color: AppColors.primary,
                                    minHeight: 8,
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Text('${e.value} (${pct.toStringAsFixed(0)}%)'),
                              ],
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          );
        },
      ),
    );
  }
}

class _KpiCard extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const _KpiCard({
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
        child: Column(
          children: [
            Text(
              value,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: const TextStyle(
                fontSize: 12,
                color: AppColors.textSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
