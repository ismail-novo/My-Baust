import 'package:flutter/material.dart';
import 'package:my_baust/core/constants/baust_grade_scale.dart';
import 'package:my_baust/core/services/academic_service.dart';

class MarksForm extends StatefulWidget {
  final String studentId;

  const MarksForm({
    super.key,
    required this.studentId,
  });

  @override
  State<MarksForm> createState() => _MarksFormState();
}

class _MarksFormState extends State<MarksForm> {
  final _formKey = GlobalKey<FormState>();
  final _academicService = AcademicService();

  final _courseController = TextEditingController();
  final _ctController = TextEditingController(text: '0');
  final _midController = TextEditingController(text: '0');
  final _labController = TextEditingController(text: '0');
  final _finalController = TextEditingController(text: '0');
  final _creditsController = TextEditingController(text: '3.0');
  final _attendanceController = TextEditingController();
  final _semesterController = TextEditingController();

  bool _isLoading = false;
  double _totalMarks = 0;
  double _gpa = 0;
  String _letter = '';

  @override
  void dispose() {
    _courseController.dispose();
    _ctController.dispose();
    _midController.dispose();
    _labController.dispose();
    _finalController.dispose();
    _creditsController.dispose();
    _attendanceController.dispose();
    _semesterController.dispose();
    super.dispose();
  }

  void _recalcTotal() {
    final ct = double.tryParse(_ctController.text.trim()) ?? 0;
    final mid = double.tryParse(_midController.text.trim()) ?? 0;
    final lab = double.tryParse(_labController.text.trim()) ?? 0;
    final fin = double.tryParse(_finalController.text.trim()) ?? 0;
    final total = ct + mid + lab + fin;
    final clamped = total.clamp(0.0, 100.0);
    setState(() {
      _totalMarks = clamped;
      _gpa = BaustGradeScale.pointFromMarks(clamped);
      _letter = BaustGradeScale.letterFromMarks(clamped);
    });
  }

  Future<void> _saveResult() async {
    if (!_formKey.currentState!.validate()) return;
    _recalcTotal();

    if (_totalMarks <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Enter at least one assessment mark'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    setState(() => _isLoading = true);

    try {
      final ct = double.parse(_ctController.text.trim());
      final mid = double.parse(_midController.text.trim());
      final lab = double.parse(_labController.text.trim());
      final fin = double.parse(_finalController.text.trim());
      final attendance = int.parse(_attendanceController.text.trim());
      final credits = double.parse(_creditsController.text.trim());

      await _academicService.addResult(
        studentId: widget.studentId,
        courseCode: _courseController.text.trim(),
        marks: _totalMarks,
        gpa: _gpa,
        attendance: attendance,
        semester: _semesterController.text.trim(),
        credits: credits,
        ct: ct,
        mid: mid,
        lab: lab,
        finalExam: fin,
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Saved: Total ${_totalMarks.toStringAsFixed(1)} → $_letter (${_gpa.toStringAsFixed(2)})',
          ),
          backgroundColor: Colors.green,
        ),
      );

      _courseController.clear();
      _ctController.text = '0';
      _midController.text = '0';
      _labController.text = '0';
      _finalController.text = '0';
      _creditsController.text = '3.0';
      _attendanceController.clear();
      _semesterController.clear();
      setState(() {
        _totalMarks = 0;
        _gpa = 0;
        _letter = '';
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(e.toString().replaceFirst('Exception: ', '')),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Widget _numField({
    required TextEditingController controller,
    required String label,
    String? hint,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        border: const OutlineInputBorder(),
      ),
      onChanged: (_) => _recalcTotal(),
      validator: (v) {
        if (v == null || v.trim().isEmpty) return 'Required (use 0 if N/A)';
        final n = double.tryParse(v);
        if (n == null) return 'Invalid number';
        if (n < 0) return 'Cannot be negative';
        return null;
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: ListView(
        children: [
          Text(
            'Student ID: ${widget.studentId}',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 4),
          Text(
            'Enter CT, Mid, Lab, Final separately. Total & GPA auto-calculate (BAUST scale).',
            style: Theme.of(context).textTheme.bodySmall,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _courseController,
            decoration: const InputDecoration(
              labelText: 'Course Code',
              hintText: 'e.g. CSE-3101',
              border: OutlineInputBorder(),
            ),
            textCapitalization: TextCapitalization.characters,
            validator: (v) =>
                (v == null || v.trim().isEmpty) ? 'Required' : null,
          ),
          const SizedBox(height: 12),
          _numField(controller: _ctController, label: 'CT (Class Test)'),
          const SizedBox(height: 12),
          _numField(controller: _midController, label: 'Midterm'),
          const SizedBox(height: 12),
          _numField(controller: _labController, label: 'Lab / Sessional'),
          const SizedBox(height: 12),
          _numField(controller: _finalController, label: 'Final Exam'),
          const SizedBox(height: 12),
          Card(
            color: Colors.blue.shade50,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Total: ${_totalMarks.toStringAsFixed(1)} / 100',
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _letter.isEmpty
                        ? 'Grade: —'
                        : 'Grade: $_letter  |  Point: ${_gpa.toStringAsFixed(2)}',
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          _numField(
            controller: _creditsController,
            label: 'Credit Hours',
            hint: 'e.g. 3.0 or 0.75',
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _attendanceController,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              labelText: 'Attendance (%)',
              border: OutlineInputBorder(),
            ),
            validator: (v) {
              if (v == null || v.trim().isEmpty) return 'Required';
              final n = int.tryParse(v);
              if (n == null) return 'Enter integer';
              if (n < 0 || n > 100) return '0–100';
              return null;
            },
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _semesterController,
            decoration: const InputDecoration(
              labelText: 'Semester / Term',
              hintText: 'e.g. Level-3 Term-2',
              border: OutlineInputBorder(),
            ),
            validator: (v) =>
                (v == null || v.trim().isEmpty) ? 'Required' : null,
          ),
          const SizedBox(height: 24),
          SizedBox(
            height: 50,
            child: ElevatedButton(
              onPressed: _isLoading ? null : _saveResult,
              child: _isLoading
                  ? const SizedBox(
                      height: 22,
                      width: 22,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Text('Save Result & Update CGPA'),
            ),
          ),
        ],
      ),
    );
  }
}
