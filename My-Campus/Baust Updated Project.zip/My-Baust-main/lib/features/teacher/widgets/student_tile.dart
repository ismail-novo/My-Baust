import 'package:flutter/material.dart';
import 'package:my_baust/core/constants/app_colors.dart';
import 'package:my_baust/features/teacher/screens/student_details_screen.dart';

class StudentTile extends StatelessWidget {
  final String name;
  final String id;
  final String? batch;
  final String? section;
  final String? level;

  const StudentTile({
    super.key,
    required this.name,
    required this.id,
    this.batch,
    this.section,
    this.level,
  });

  @override
  Widget build(BuildContext context) {
    final subtitleParts = <String>[id];
    if (batch != null && batch!.isNotEmpty) subtitleParts.add('Batch $batch');
    if (section != null && section!.isNotEmpty) subtitleParts.add('Sec $section');
    if (level != null && level!.isNotEmpty) subtitleParts.add('L$level');

    return Card(
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: AppColors.primary.withValues(alpha: 0.12),
          child: Text(
            name.isNotEmpty ? name[0].toUpperCase() : 'S',
            style: const TextStyle(
              color: AppColors.primary,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        title: Text(
          name,
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        subtitle: Text(subtitleParts.join(' • ')),
        trailing: const Icon(Icons.chevron_right),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => StudentDetailsScreen(
                studentId: id,
                studentName: name,
              ),
            ),
          );
        },
      ),
    );
  }
}
