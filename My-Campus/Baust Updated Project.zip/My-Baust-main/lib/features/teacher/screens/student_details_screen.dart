import 'package:flutter/material.dart';
import 'package:my_baust/core/constants/app_sizes.dart';
import 'package:my_baust/features/teacher/screens/attendance_input_screen.dart';
import 'package:my_baust/features/teacher/screens/marks_input_screen.dart';

class StudentDetailsScreen extends StatelessWidget {
  final String studentId;
  final String studentName;

  const StudentDetailsScreen({
    super.key,
    required this.studentId,
    this.studentName = '',
  });

  @override
  Widget build(BuildContext context) {
    final name = studentName.isEmpty ? 'Student' : studentName;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Student Details'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(AppSizes.md),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(AppSizes.md),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text('ID: $studentId'),
                  ],
                ),
              ),
            ),
            const SizedBox(height: AppSizes.lg),
            SizedBox(
              height: AppSizes.buttonHeight,
              child: ElevatedButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => MarksInputScreen(studentId: studentId),
                    ),
                  );
                },
                icon: const Icon(Icons.edit_note),
                label: const Text('Input Marks'),
              ),
            ),
            const SizedBox(height: AppSizes.md),
            SizedBox(
              height: AppSizes.buttonHeight,
              child: OutlinedButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => AttendanceInputScreen(
                        studentId: studentId,
                        studentName: name,
                      ),
                    ),
                  );
                },
                icon: const Icon(Icons.event_available_outlined),
                label: const Text('Enter Attendance'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
