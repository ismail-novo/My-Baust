import 'package:flutter/material.dart';
import 'package:my_baust/core/constants/app_colors.dart';
import 'package:my_baust/core/constants/app_sizes.dart';
import 'package:my_baust/core/services/auth_service.dart';
import 'package:my_baust/features/auth/screens/role_selection_screen.dart';
import 'package:my_baust/features/teacher/screens/student_search_screen.dart';
import 'package:my_baust/features/teacher/screens/teacher_analytics_screen.dart';
import 'package:my_baust/widgets/section_header.dart';

class TeacherDashboard extends StatelessWidget {
  final String department;

  const TeacherDashboard({
    super.key,
    required this.department,
  });

  @override
  Widget build(BuildContext context) {
    final authService = AuthService();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Teacher Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Logout',
            onPressed: () async {
              await authService.logout();
              if (context.mounted) {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const RoleSelectionScreen(),
                  ),
                  (route) => false,
                );
              }
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(AppSizes.md),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(AppSizes.md),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppColors.secondary.withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(
                        Icons.business_outlined,
                        color: AppColors.secondary,
                        size: 28,
                      ),
                    ),
                    const SizedBox(width: AppSizes.md),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Department',
                            style: TextStyle(
                              fontSize: 13,
                              color: AppColors.textSecondary,
                            ),
                          ),
                          Text(
                            department.isEmpty ? 'Not set' : department,
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: AppColors.textPrimary,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: AppSizes.lg),
            const SectionHeader(
              title: 'Actions',
              subtitle: 'Manage students in your department',
            ),
            const SizedBox(height: AppSizes.sm),
            SizedBox(
              height: AppSizes.buttonHeight,
              child: ElevatedButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) =>
                          StudentSearchScreen(department: department),
                    ),
                  );
                },
                icon: const Icon(Icons.search),
                label: const Text('Search Students'),
              ),
            ),
            const SizedBox(height: AppSizes.md),
            SizedBox(
              height: AppSizes.buttonHeight,
              child: OutlinedButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) =>
                          TeacherAnalyticsScreen(department: department),
                    ),
                  );
                },
                icon: const Icon(Icons.analytics_outlined),
                label: const Text('Class Analytics'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
