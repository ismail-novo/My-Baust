import 'package:flutter/material.dart';
import 'package:my_baust/core/constants/app_colors.dart';
import 'package:my_baust/core/constants/app_sizes.dart';
import 'package:my_baust/core/services/analytics_service.dart';
import 'package:my_baust/features/analytics/widgets/bar_chart_widget.dart';
import 'package:my_baust/widgets/empty_state.dart';
import 'package:my_baust/widgets/error_state.dart';
import 'package:my_baust/widgets/loading_widget.dart';
import 'package:my_baust/widgets/section_header.dart';

class TeacherAnalyticsScreen extends StatefulWidget {
  final String department;

  const TeacherAnalyticsScreen({super.key, required this.department});

  @override
  State<TeacherAnalyticsScreen> createState() => _TeacherAnalyticsScreenState();
}

class _TeacherAnalyticsScreenState extends State<TeacherAnalyticsScreen> {
  final _service = AnalyticsService();
  late Future<ClassAnalytics> _future;

  String _batch = '';
  String _section = '';
  String _level = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() {
    setState(() {
      _future = _service.getDepartmentAnalytics(
        department: widget.department,
        batch: _batch.isEmpty ? null : _batch,
        section: _section.isEmpty ? null : _section,
        level: _level.isEmpty ? null : _level,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Analytics • ${widget.department}'),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _load),
        ],
      ),
      body: FutureBuilder<ClassAnalytics>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const LoadingWidget(message: 'Loading class analytics...');
          }
          if (snapshot.hasError) {
            return ErrorState(
              message: '${snapshot.error}',
              onRetry: _load,
            );
          }

          final a = snapshot.data!;
          if (a.studentCount == 0) {
            return const EmptyState(
              icon: Icons.analytics_outlined,
              title: 'No students found',
              subtitle: 'Adjust filters or add students to this department.',
            );
          }

          // Convert distribution to double map for bar chart
          final distData = a.cgpaDistribution.map(
            (k, v) => MapEntry(k, v.toDouble()),
          );

          return ListView(
            padding: const EdgeInsets.all(AppSizes.md),
            children: [
              // Filter chips (simple)
              Wrap(
                spacing: 8,
                children: [
                  _FilterDropdown(
                    label: 'Batch',
                    value: _batch,
                    options: a.students
                        .map((s) => s['batch'] as String)
                        .where((s) => s.isNotEmpty)
                        .toSet()
                        .toList(),
                    onChanged: (v) {
                      _batch = v;
                      _load();
                    },
                  ),
                  _FilterDropdown(
                    label: 'Section',
                    value: _section,
                    options: a.students
                        .map((s) => s['section'] as String)
                        .where((s) => s.isNotEmpty)
                        .toSet()
                        .toList(),
                    onChanged: (v) {
                      _section = v;
                      _load();
                    },
                  ),
                  _FilterDropdown(
                    label: 'Level',
                    value: _level,
                    options: a.students
                        .map((s) => s['level'] as String)
                        .where((s) => s.isNotEmpty)
                        .toSet()
                        .toList(),
                    onChanged: (v) {
                      _level = v;
                      _load();
                    },
                  ),
                ],
              ),
              const SizedBox(height: AppSizes.md),

              Row(
                children: [
                  Expanded(
                    child: _KpiCard(
                      label: 'Students',
                      value: '${a.studentCount}',
                      color: AppColors.primary,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _KpiCard(
                      label: 'Avg CGPA',
                      value: a.averageCgpa.toStringAsFixed(2),
                      color: AppColors.secondary,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: AppSizes.lg),

              const SectionHeader(title: 'CGPA Distribution'),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(AppSizes.md),
                  child: SimpleBarChart(
                    data: distData,
                    maxY: (a.cgpaDistribution.values.fold<int>(
                              0, (p, c) => p > c ? p : c) +
                          1)
                        .toDouble(),
                    yLabel: 'Count',
                  ),
                ),
              ),
              const SizedBox(height: AppSizes.lg),

              const SectionHeader(title: 'Students (by CGPA)'),
              ...(() {
                final sorted = List<Map<String, dynamic>>.from(a.students)
                  ..sort((x, y) =>
                      (y['cgpa'] as double).compareTo(x['cgpa'] as double));
                return sorted.take(20).map((s) {
                  final cgpa = s['cgpa'] as double;
                  return Card(
                    child: ListTile(
                      title: Text(s['name']?.toString() ?? ''),
                      subtitle: Text(
                        '${s['studentId']} • Batch ${s['batch']} • Sec ${s['section']}',
                      ),
                      trailing: Text(
                        cgpa.toStringAsFixed(2),
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: cgpa >= 3.0
                              ? AppColors.success
                              : cgpa >= 2.0
                                  ? AppColors.warning
                                  : AppColors.error,
                        ),
                      ),
                    ),
                  );
                });
              })(),
            ],
          );
        },
      ),
    );
  }
}

class _KpiCard extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const _KpiCard({
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text(
              value,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
            Text(
              label,
              style: const TextStyle(color: AppColors.textSecondary),
            ),
          ],
        ),
      ),
    );
  }
}

class _FilterDropdown extends StatelessWidget {
  final String label;
  final String value;
  final List<String> options;
  final ValueChanged<String> onChanged;

  const _FilterDropdown({
    required this.label,
    required this.value,
    required this.options,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<String>(
      onSelected: onChanged,
      itemBuilder: (_) => [
        PopupMenuItem(value: '', child: Text('All $label')),
        ...options.map((o) => PopupMenuItem(value: o, child: Text(o))),
      ],
      child: Chip(
        label: Text(value.isEmpty ? label : '$label: $value'),
        backgroundColor: value.isEmpty
            ? null
            : AppColors.primary.withValues(alpha: 0.12),
      ),
    );
  }
}
