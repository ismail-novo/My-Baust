import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:my_baust/core/constants/app_colors.dart';
import 'package:my_baust/core/constants/app_sizes.dart';
import 'package:my_baust/features/teacher/widgets/student_tile.dart';
import 'package:my_baust/widgets/empty_state.dart';
import 'package:my_baust/widgets/error_state.dart';
import 'package:my_baust/widgets/loading_widget.dart';

class StudentSearchScreen extends StatefulWidget {
  final String department;

  const StudentSearchScreen({
    super.key,
    required this.department,
  });

  @override
  State<StudentSearchScreen> createState() => _StudentSearchScreenState();
}

class _StudentSearchScreenState extends State<StudentSearchScreen> {
  List<QueryDocumentSnapshot> _allStudents = [];
  List<QueryDocumentSnapshot> _filtered = [];
  bool _loading = true;
  String? _error;

  final _searchController = TextEditingController();
  String _batchFilter = '';
  String _sectionFilter = '';
  String _levelFilter = '';

  @override
  void initState() {
    super.initState();
    _loadStudents();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadStudents() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final dept = widget.department.trim().toUpperCase();

      // Primary query (normalized uppercase)
      var snapshot = await FirebaseFirestore.instance
          .collection('students')
          .where('department', isEqualTo: dept)
          .get();

      // Fallback: if no results, load all and filter case-insensitively
      // (helps older records stored as "Cse" / "cse")
      if (snapshot.docs.isEmpty) {
        final all = await FirebaseFirestore.instance.collection('students').get();
        final matched = all.docs.where((doc) {
          final d = (doc.data()['department'] ?? '').toString().trim().toUpperCase();
          return d == dept;
        }).toList();
        setState(() {
          _allStudents = matched;
          _applyFilters();
          _loading = false;
        });
        return;
      }

      setState(() {
        _allStudents = snapshot.docs;
        _applyFilters();
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  void _applyFilters() {
    final query = _searchController.text.trim().toLowerCase();

    _filtered = _allStudents.where((doc) {
      final data = doc.data() as Map<String, dynamic>;
      final name = (data['name'] ?? '').toString().toLowerCase();
      final id = (data['studentId'] ?? '').toString().toLowerCase();
      final batch = (data['batch'] ?? '').toString();
      final section = (data['section'] ?? '').toString();
      final level = (data['level'] ?? '').toString();

      if (query.isNotEmpty && !name.contains(query) && !id.contains(query)) {
        return false;
      }
      if (_batchFilter.isNotEmpty && batch != _batchFilter) return false;
      if (_sectionFilter.isNotEmpty && section != _sectionFilter) return false;
      if (_levelFilter.isNotEmpty && level != _levelFilter) return false;

      return true;
    }).toList();
  }

  Set<String> _uniqueValues(String field) {
    final values = <String>{};
    for (final doc in _allStudents) {
      final data = doc.data() as Map<String, dynamic>;
      final v = (data[field] ?? '').toString().trim();
      if (v.isNotEmpty) values.add(v);
    }
    return values;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Students • ${widget.department}'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadStudents,
          ),
        ],
      ),
      body: Column(
        children: [
          // Search + filters
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Column(
              children: [
                TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    hintText: 'Search by name or ID',
                    prefixIcon: const Icon(Icons.search),
                    suffixIcon: _searchController.text.isNotEmpty
                        ? IconButton(
                            icon: const Icon(Icons.clear),
                            onPressed: () {
                              _searchController.clear();
                              setState(_applyFilters);
                            },
                          )
                        : null,
                  ),
                  onChanged: (_) => setState(_applyFilters),
                ),
                const SizedBox(height: 10),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      _FilterChip(
                        label: 'Batch',
                        value: _batchFilter,
                        options: _uniqueValues('batch'),
                        onChanged: (v) {
                          setState(() {
                            _batchFilter = v;
                            _applyFilters();
                          });
                        },
                      ),
                      const SizedBox(width: 8),
                      _FilterChip(
                        label: 'Section',
                        value: _sectionFilter,
                        options: _uniqueValues('section'),
                        onChanged: (v) {
                          setState(() {
                            _sectionFilter = v;
                            _applyFilters();
                          });
                        },
                      ),
                      const SizedBox(width: 8),
                      _FilterChip(
                        label: 'Level',
                        value: _levelFilter,
                        options: _uniqueValues('level'),
                        onChanged: (v) {
                          setState(() {
                            _levelFilter = v;
                            _applyFilters();
                          });
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const Divider(height: 1),
          Expanded(
            child: _loading
                ? const LoadingWidget(message: 'Loading students...')
                : _error != null
                    ? ErrorState(
                        message: _error!,
                        onRetry: _loadStudents,
                      )
                    : _filtered.isEmpty
                        ? const EmptyState(
                            icon: Icons.people_outline,
                            title: 'No students found',
                            subtitle: 'Try adjusting your filters.',
                          )
                        : ListView.builder(
                            padding: const EdgeInsets.all(AppSizes.sm),
                            itemCount: _filtered.length,
                            itemBuilder: (context, index) {
                              final data = _filtered[index].data()
                                  as Map<String, dynamic>;
                              return StudentTile(
                                name: data['name']?.toString() ?? '',
                                id: data['studentId']?.toString() ?? '',
                                batch: data['batch']?.toString(),
                                section: data['section']?.toString(),
                                level: data['level']?.toString(),
                              );
                            },
                          ),
          ),
        ],
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final String value;
  final Set<String> options;
  final ValueChanged<String> onChanged;

  const _FilterChip({
    required this.label,
    required this.value,
    required this.options,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<String>(
      onSelected: onChanged,
      itemBuilder: (context) {
        return [
          PopupMenuItem(
            value: '',
            child: Text('All $label'),
          ),
          ...options.map(
            (o) => PopupMenuItem(
              value: o,
              child: Text(o),
            ),
          ),
        ];
      },
      child: Chip(
        label: Text(value.isEmpty ? label : '$label: $value'),
        backgroundColor: value.isEmpty
            ? null
            : AppColors.primary.withValues(alpha: 0.12),
        side: BorderSide(
          color: value.isEmpty
              ? AppColors.border
              : AppColors.primary.withValues(alpha: 0.4),
        ),
      ),
    );
  }
}
