import 'package:flutter/material.dart';
import 'package:my_baust/core/constants/app_sizes.dart';
import 'package:my_baust/core/services/academic_service.dart';

class AttendanceInputScreen extends StatefulWidget {
  final String studentId;
  final String studentName;

  const AttendanceInputScreen({
    super.key,
    required this.studentId,
    required this.studentName,
  });

  @override
  State<AttendanceInputScreen> createState() => _AttendanceInputScreenState();
}

class _AttendanceInputScreenState extends State<AttendanceInputScreen> {
  final _formKey = GlobalKey<FormState>();
  final _academicService = AcademicService();

  final _courseController = TextEditingController();
  final _semesterController = TextEditingController();
  final _totalController = TextEditingController();
  final _attendedController = TextEditingController();

  bool _isLoading = false;

  @override
  void dispose() {
    _courseController.dispose();
    _semesterController.dispose();
    _totalController.dispose();
    _attendedController.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      final total = int.parse(_totalController.text.trim());
      final attended = int.parse(_attendedController.text.trim());

      await _academicService.saveAttendance(
        studentId: widget.studentId,
        courseCode: _courseController.text.trim(),
        semester: _semesterController.text.trim(),
        totalClasses: total,
        attendedClasses: attended,
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Attendance saved'),
          backgroundColor: Colors.green,
        ),
      );

      _courseController.clear();
      _semesterController.clear();
      _totalController.clear();
      _attendedController.clear();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(e.toString().replaceFirst('Exception: ', '')),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Enter Attendance'),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(AppSizes.md),
          children: [
            Text(
              widget.studentName,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            Text('ID: ${widget.studentId}'),
            const SizedBox(height: AppSizes.lg),
            TextFormField(
              controller: _courseController,
              decoration: const InputDecoration(
                labelText: 'Course Code',
                hintText: 'e.g. CSE-3101',
              ),
              textCapitalization: TextCapitalization.characters,
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Required' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _semesterController,
              decoration: const InputDecoration(
                labelText: 'Semester',
                hintText: 'e.g. Level-3 Term-1',
              ),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Required' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _totalController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Total Classes',
              ),
              validator: (v) {
                if (v == null || v.trim().isEmpty) return 'Required';
                final n = int.tryParse(v);
                if (n == null || n < 0) return 'Enter a valid number';
                return null;
              },
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _attendedController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Classes Attended',
              ),
              validator: (v) {
                if (v == null || v.trim().isEmpty) return 'Required';
                final n = int.tryParse(v);
                if (n == null || n < 0) return 'Enter a valid number';
                final total = int.tryParse(_totalController.text.trim()) ?? 0;
                if (n > total) return 'Cannot exceed total classes';
                return null;
              },
            ),
            const SizedBox(height: 24),
            SizedBox(
              height: AppSizes.buttonHeight,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _save,
                child: _isLoading
                    ? const SizedBox(
                        height: 22,
                        width: 22,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Text('Save Attendance'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
