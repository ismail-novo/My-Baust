# BAUST-UIMS — University Intelligence & Management System

**Tagline:** One University. One Intelligent Digital Ecosystem.

> **Portfolio / prototype project** designed around publicly available information from  
> [Bangladesh Army University of Science and Technology (BAUST), Saidpur](https://www.baust.edu.bd/).  
> **Not an official BAUST product.** Not connected to BAUST internal systems.

---

## Current status (incremental build)

Built on top of the existing My Campus Flutter + Firebase app.

### Implemented and working

| Area | Status |
|------|--------|
| Firebase Auth (Student + Teacher) | Done |
| Role-based routing | Done |
| Firestore Security Rules file | Done (deploy required) |
| Design system (Material 3) | Done |
| Results entry + student results view | Done |
| **BAUST official grade scale (A+ … F)** | **Done** |
| **Credit-weighted GPA/CGPA (BAUST formula)** | **Done** |
| Attendance entry + view | Done |
| Student search + filters | Done |
| Student & Teacher analytics dashboards | Done |
| Configurable BAUST departments list | Done |

### Official BAUST policies used (verified)

- Grading scale from BAUST Examination Policy (A+ = 4.00 … F = 0.00)
- Credit-weighted GPA/CGPA: `Σ(Ci × Gi) / Σ(Ci)`, rounded to 2 decimals
- Minimum CGPA for degree: 2.20
- Honors threshold: 3.75
- Faculties/Departments from public website (CSE, EEE, ICT, ME, IPE, CE, DBA, AIS, ENG, AS)

### Not yet implemented (later phases)

- Full ERP modules (Admission, Finance, Library, Hostel, …)
- Admin / Registrar roles
- Data Science Lab
- FastAPI + ML Studio
- Credit transfer, backlog, official transcript PDF

---

## How to run

```bash
cd My-Baust-main
flutter pub get
flutter run
```

Deploy Firestore rules:

```bash
firebase deploy --only firestore:rules
```

---

## Collections

| Collection | Purpose |
|------------|---------|
| `users` | Role + profile |
| `students` | Academic profile + CGPA |
| `teachers` | Teacher profile |
| `results` | Course results (now includes `credits`) |
| `attendance` | Course attendance |

Older result documents without `credits` default to **3.0** credits for CGPA calculation.

---

## Project structure (key)

```
lib/
├── core/
│   ├── constants/   # AppColors, AppSizes, baust_grade_scale, baust_departments
│   ├── services/    # Auth, Academic, Analytics
│   └── theme/
├── features/
│   ├── auth/
│   ├── student/
│   ├── teacher/
│   └── analytics/
├── models/
└── widgets/
```

---

## Roadmap (aligned with master prompt)

1. ~~Research + Audit~~  
2. ~~Auth, Security, Design, Results, Attendance, Analytics~~  
3. **BAUST grade scale + credit-weighted CGPA** ← current  
4. Admin role + departments/programs as entities  
5. Notices + academic calendar  
6. FastAPI skeleton  
7. Data Science Lab (v1)  
8. ML Studio (one clear task, real train/eval)  
9. Portfolio polish  

---

## Disclaimer

This is an independent educational / portfolio project.  
It does **not** claim official endorsement by BAUST.  
Do not use with real production student data without proper authorization and hardened security.
